from flask import Flask, render_template, request
import base64
import os

app = Flask(__name__)

# Capture folder create karo agar na ho
CAPTURE_DIR = "capture"
if not os.path.exists(CAPTURE_DIR):
    os.makedirs(CAPTURE_DIR)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():
    try:
        data = request.json["img"]
        img_data = data.split(",")[1]  # remove base64 header
        
        # File path set karo
        filename = os.path.join(CAPTURE_DIR, "captured.png")  

        # File save karo
        with open(filename, "wb") as f:
            f.write(base64.b64decode(img_data))

        print(f"[✓] Image saved in {filename}")
        return {"status": "success", "file": filename}
    except Exception as e:
        print("Error saving image:", e)
        return {"status": "error", "message": str(e)}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
